After having installed openDX, put dxVisualizer into 
%USER%\Appdata\Roaming\Microsoft\Windows\SendTo
% GETEAMPLITUDE returns the constant value of normalised 
% electrical field component E0 at the ports

function E0 = computeEAmplitude(project, omega)

% define physical constants
epsilon_0 = 8.854e-12;
mu_0 = 4*pi*1e-7;

% wave number
k0 = omega * sqrt(epsilon_0 * mu_0);

portWidth = project.waveguideWidth;
beta = sqrt(k0^2 - pi ./ portWidth.^2);
E0 = 1j .* sqrt(2 * omega * mu_0 ./ beta ./ portWidth);





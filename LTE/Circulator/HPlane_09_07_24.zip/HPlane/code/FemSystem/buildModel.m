% PROJECTREADER(PROJECTNAME) for string PROJECTNAME, 
% returns a struct with all topological and geometrical data
function Model = buildModel(projectPath, projectName, order) 

Model.name = projectName;

% reading Model data
meshData = readMesh(projectPath, projectName);
boundary = readBoundary(projectPath, projectName);
material = readMaterial(projectPath, projectName);
materialProperty = readMaterialProperty(material, projectPath);

% --------------------------------------------------------
% create Model
% --------------------------------------------------------

% contain all topology data in field 'topo'
currentId = 0; % initialise Id for enumerating Nodes etc
Model.topo.node = buildNodeStruct(meshData, currentId);
currentId = currentId + length(Model.topo.node);
Model.topo.edge = buildEdgeStruct(meshData, currentId);
currentId = currentId + length(Model.topo.edge);
Model.topo.face = buildFaceStruct(meshData, currentId);

% contain all geometric data in field 'geo'
Model.geo.poly_edges = meshData.poly_edges;
Model.geo.poly_faces = meshData.poly_faces;
Model.geo.material = buildMaterialStruct(material, meshData, materialProperty);
Model.geo.materialProperty = materialProperty;
Model.geo.boundary = buildBoundaryStruct(boundary, meshData);

Model.materialDim = length(Model.geo.material);
Model.boundaryDim = length(Model.geo.boundary);

Model.waveguideWidth = waveguideWidth(Model);

% --------------------------------------------------------
% determine general dimensions
% --------------------------------------------------------

% count all nodes
Model.nodeDim = meshData.nodeDim;

% count all edges
Model.edgeDim = meshData.edgeDim;

% count all elements
Model.faceDim = meshData.faceDim;

% count all components
Model.componentDim = Model.nodeDim + Model.edgeDim + Model.faceDim;


% --------------------------------------------------------
% establish relations between geometric and topologic items
% --------------------------------------------------------
Model.link.face2mtr = linkFace2Material(Model);
Model.link.edge2bc = linkEdge2Boundary(Model);


% --------------------------------------------------------
% Depending on the order, several position indices per 
% component are required. These indices are listed in a table
% and can be accessed via unique identifiers
% --------------------------------------------------------
Model.geo.domain = domainDimensions(Model, order);
Model.geo.index = createIndexTable(Model, order);






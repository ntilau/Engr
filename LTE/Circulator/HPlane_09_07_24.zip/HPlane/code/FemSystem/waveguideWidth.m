function width = waveguideWidth(Model)

boundary = Model.geo.boundary;

portCnt = 0;
for iBound = 1:Model.boundaryDim        
    if strcmp(boundary(iBound).bcType, 'TRANSFINITE_BC');
        portCnt = portCnt + 1;
        peId = boundary(iBound).polyEdgesId;      
        width(portCnt) = polyEdgesLength(Model, peId);
    end
end
                
        
        
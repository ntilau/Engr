% -------------------------------------------------------
% H-plane solver 
% -------------------------------------------------------

clear;
% close all;
format long;

addpath('FemSystem', 'Io', 'General');

%% physical constants
EPSILON_0 = 8.854e-12;
MU_0 = 4*pi*1e-7;
C_0 = 1 / sqrt(EPSILON_0 * MU_0);

%% define variables
% set name and path for Model files
projectName = 'webb_filter';
projectPath = '..\Projects\webb_filter_0.005x0.01x0.04\';
% set path where system matrices should be written
resultPath  = strcat(projectPath, 'system_matrices\');
if ~isdir(resultPath)
    mkdir(resultPath);
end

showMesh                = false;
showMovie               = false;
storeMovie              = false; % save movie
writeReflectionDataFile = false;
plotReflectionData      = true;
writeSysMat             = true; % write system matrices to file
impFormFlag             = false; % solving impedance formulation

% set start and end of frequency range and steps within
startFrequency = 15e9;
endFrequency   = 30e9;
nFrequencyStep = 51;
frequency = linspace(startFrequency, endFrequency, nFrequencyStep);

% set number of movie-frames per oscillation 
nrOfFrames = 1;

% set basis function order 
order = 1;

%% read Model data
Model = buildModel(projectPath, projectName, order);

%% important system sizes
% number of non-port variables
nonPortVarDim = Model.geo.domain.nonPort.scalarDim;
% number of ports carrying transfinite elements
portDim = length(Model.geo.domain.port);


%% set excitation parameters
% amplitude of incident wave
a0 = 1;

sysMatDim = Model.geo.domain.overallDim;
networkMat = zeros(portDim);

%% assemble stiffness and mass matrix
fprintf('\nSystem matrix assembly...\n');
tic
[stiffMatrix, massMatrix] = assembleSystemMatrices(Model, order);

% impose dirichlet boundary conditions in main equation system
[stiffMatrix, massMatrix, dirIndex] = imposeDirichlet(Model, order, stiffMatrix, massMatrix);
assemblingTime = toc;

% start measurement for solving time
tic
S = cell(nFrequencyStep, 1);
for iFreq = 1:nFrequencyStep;
      
    % print status message on command line
    fprintf('\nFrequency step: %d of %d steps\n', iFreq, nFrequencyStep);        
    
    f = frequency(iFreq);
    omega = 2 * pi * f;
    k0 = omega / C_0;
    
                      
    % ---------------------------------------
    % induce modal functions
    % --------------------------------------- 
    % electrical field amplitude for TE10-mode
    eAmplitude = computeEAmplitude(Model, omega);
    [C portSol] = createModeRestrictionOperator(Model, order, omega, eAmplitude);
    stiffMatReduced = C' * stiffMatrix * C;
    massMatReduced = C' * massMatrix * C;
    
    sysMatReduced = stiffMatReduced - k0^2 * massMatReduced;      

    % new size of reduced system matrix
    [tmp sysMatRedDim] = size(sysMatReduced); 
    
    for iPort = 1:portDim
        % ---------------------------------------
        % define excitation vector on right hand side
        % ---------------------------------------
        excitation = sparse(sysMatRedDim,1);
        excitation(nonPortVarDim + iPort, 1) = a0;

        % calculate right hand side
        if impFormFlag
            rhs = j / omega * MU_0 * excitation; %#ok<UNRCH>
        else
            rhs =  - 1j / omega * 2 * MU_0 * excitation;
        end

        % ---------------------------------------
        % add reaction matrix D to system matrix
        % ---------------------------------------
        D = sparse(sysMatRedDim, sysMatRedDim);
        D((nonPortVarDim + 1):sysMatRedDim, (nonPortVarDim + 1):sysMatRedDim) = eye(portDim);

        % write system matrices to file
        if writeSysMat && iFreq == 1
            if iPort == 1
                mmwrite(strcat(resultPath, 'k^2 matrix.mm'), massMatReduced);
                mmwrite(strcat(resultPath, 'system matrix.mm'), sysMatReduced);
                mmwrite(strcat(resultPath, 'ident0.mm'), D);
            end
            writeFullVector(full(rhs), sprintf('%srhs%d.fvec', resultPath, iPort - 1));
            writeFullVector(full(excitation), sprintf('%sleftVec%d.fvec', resultPath, iPort - 1));
        end

        if ~impFormFlag && iPort == 1
            sysMatReduced = sysMatReduced  - 1j / omega * MU_0 * D;
        end

        % calculate solution
        solution = sysMatReduced \ rhs;

        % calculate network matrix column
        if impFormFlag
            nonPortVarDim = Model.geo.domain.nonPort.scalarDim; %#ok<UNRCH>
            networkMat(:,iPort) = solution((Model.geo.domain.nonPort.scalarDim + 1):end);
        else
            nonPortVarDim = Model.geo.domain.nonPort.scalarDim;
            networkMat(:,iPort) = solution((nonPortVarDim + 1):end) - excitation((nonPortVarDim + 1):end);
        end

        % compute FEM solution from TFE solution (reconstruct port fields)
        if 1 % iFreq == freqSteps
            solutionFEM = sparse(sysMatDim,1);
            solutionFEM(1:sysMatRedDim - portDim,1) = solution(1:sysMatRedDim - portDim,1);
            solutionFEM = solutionFEM + a0 * portSol{1};
            %         solutionFEM = solutionFEM + S(2,1) * portSol{2};

            %         rhsFEM = sparse(sysMatDim, 1);
            %         imposeMode;
            %
            %         solutionFEM = systemMatrix \ rhsFEM;
            %Frames = plotFEM_solution(solutionFEM, Model, order);
            %movie(Frames, 10);
            %         break;
        end
        
    end % iPort loop
    
    if impFormFlag
        S{iFreq} = inv(networkMat - eye(portDim)) ...
            * (networkMat + eye(portDim));  %#ok<UNRCH>
    else 
        S{iFreq} = networkMat; 
    end   

end % iFreq loop

% stop solving time clock
solving_time = toc;

% store movie
if storeMovie
    movieFileName = sprintf('..\\movies\\%s_order_%d.avi', projectName, order);
    movie2avi(frames, movieFileName, 'compression', 'None');
end

% write reflection coefficient data to file
if writeReflectionDataFile
    plotFile = sprintf('..\\plots\\%s_order_%d.dat', projectName, order);
    dlmwrite(plotFile, R, '\t');
end

% plot magnitude of s-parameters
if plotReflectionData    
    figure;
    portS = sortNetworkParamsByPorts(S);
    plot(frequency, abs(portS{1,1}), '-xr');
    xlabel('Frequency (Hz)');
    ylabel('s11 (dB)');  
end

% print cpu times on standard output
printCalcData(Model, assemblingTime, solving_time);



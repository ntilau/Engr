% -------------------------------------------------------
% creates stiffness element matrix for one element
% -------------------------------------------------------

function stiffElemMat = stiffElemMatBuilder( elemCnt, project, order )



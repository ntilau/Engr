%%MatrixMarket matrix coordinate real symmetric
% Generated 24-Jul-2009
491 491 2
490 490  1
491 491  1
